

import React, { useState, useEffect, useRef } from 'react'
import Camera from '../shared/Camera'
import { supabase } from '../supabase'
import './TechnicianApp.css'


// --- Stats Grid Component ---
function StatsGrid({ appointments }) {
  const statusList = ['assigned', 'in_progress', 'completed']
  const STATUS_COLORS = {
    assigned: '#f59e0b',
    in_progress: '#3b82f6',
    completed: '#10b981'
  }

  return (
    <div className="stats-grid-tech">
      <div className="stat-card-tech">
        <div className="stat-value-tech">{appointments.length}</div>
        <div className="stat-label-tech">Total Jobs</div>
      </div>
      {statusList.map(status => (
        <div
          className="stat-card-tech"
          key={status}
          style={{ backgroundColor: STATUS_COLORS[status] }}
        >
          <div className="stat-value-tech">
            {appointments.filter(a => a.status === status).length}
          </div>
          <div className="stat-label-tech">
            {status.replace('_', ' ').toUpperCase()}
          </div>
        </div>
      ))}
    </div>
  )
}



// --- Technician App Component ---
export default function TechnicianApp({ user, onLogout }) {
  const [screen, setScreen] = useState('appointments')
  const [appointments, setAppointments] = useState([])
  const [selectedAppointment, setSelectedAppointment] = useState(null)
  const [showCamera, setShowCamera] = useState(false)
  const [workPhotos, setWorkPhotos] = useState([])
  const [notes, setNotes] = useState('')
  const [cameraMode, setCameraMode] = useState('before')
  const [activeFilter, setActiveFilter] = useState('all')
  const [maintenanceReminders, setMaintenanceReminders] = useState([])
  const [showProfile, setShowProfile] = useState(false);
  const [technician, setTechnician] = useState(null);

useEffect(() => {
    if (user?.id) {  // Ensure there's a user ID
      async function fetchTechnicianData() {
        const { data, error } = await supabase
          .from('technicians')
          .select('*')  // Fetch all fields for technician
          .eq('user_id', user.id);  // Use user.id to get technician data

        if (error) {
          console.error("Error fetching technician data:", error);
          return;
        }

        // Debugging line to check technician data
        console.log("Fetched Technician Data:", data);

        // Set technician data if it's available
        if (data && data.length > 0) {
          const technicianData = data[0];
          setTechnician({
            name: technicianData.name,
            email: technicianData.email,
            role: technicianData.role || 'technician',  // Default to 'technician' if role is missing
          });
        }
      }

      fetchTechnicianData();  // Call the fetch function
    }
  }, [user?.id]);  // Trigger this effect when user.id changes


   function showTechnicianProfile(e) {
    e.preventDefault();  // Prevent default anchor behavior
    setShowProfile(true);  // Show the profile modal
  }

  const preventiveIntervals = {
  "4d376ac8-2b4e-4918-b3d3-7f026cb99ba7": 60, // AC Installation Basic
  "01a76081-771d-463b-9508-1ae2410dde47": 45, // AC Repair
  "1dd16c71-7392-48a0-926d-5b0fcc1818ec": 30, // AC Maintenance
  "0935c1b6-ca4f-4d76-b9eb-4d67df5d227f": 60, // Split-type AC Installation
  "82091676-9819-44a5-9784-45c0642082a1": 60, // Window-type AC Installation
  "4d802600-9ec2-4893-8674-8c78bc6ecb14": 60, // Ceiling Cassette AC Installation
  "dc6fb40e-32b9-45bb-a295-beff8f6072c8": 30, // Portable AC Setup
  "745185be-b8d9-4e69-8b81-69a45b42fd13": 60, // Ducted AC Installation
  "cf0c1e3a-86ca-49e3-ade0-fbac6307c5a9": 45, // AC Not Cooling
  "8a6eebcb-727c-4fb9-af39-18fd692ad86e": 30, // Water Leakage Fix
  "d3adddb7-13ee-413f-9045-11f311491bfe": 45, // AC Compressor Replacement
  "3f04cce4-e0a6-41d2-9527-e499af381c89": 45, // AC Electrical Fault
  "7d83399d-f639-4633-aecb-0112831a159f": 30, // Strange AC Noise Repair
  "3f049aca-f623-4a9c-8b15-4f52af6db177": 60, // AC Coil Cleaning
  "48352c7f-6ca3-445f-8597-7fb7958fd98d": 30, // Filter Cleaning/Replacement
  "32128b70-c635-4419-b1cf-c6ea6cecab15": 60, // Full AC Check-up
  "7ecce893-74cf-4b7b-936d-0a285e4b6d09": 30, // Gas Top-up
  "e2692bd6-5e65-48a2-a61c-ff091d812789": 45, // Thermostat Calibration
  "c1e524c8-64f5-4922-8537-19ffcc41a18b": 60, // Aircon Unit Relocation 
  "19a6029e-a206-423d-8088-09ad2cb22a90": 60, // AC Energy Optimization Services 
  "82cc28a6-f812-4f5c-8cb0-f0ff242e8c9a": 60, // Cooling System Consultation & Assessment 
  "5bd67041-7f29-4b7c-960a-8ed9e1418587": 30, // Centralized AC System Installation 
  "94e42a93-2771-4efe-9f66-8aa63fe24e0d": 60, // Thermal Insulation and AC Efficiency Upgrade 
};
  // --- Pagination states ---
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5

  const subscriptionRef = useRef(null)

  useEffect(() => {
    if (user?.id) {
      loadAppointments()
      loadMaintenanceReminders()
      setupRealtime()
    }
    return () => {
      subscriptionRef.current?.unsubscribe()
    }
  }, [user])

  // reset to page 1 when filter changes or appointments refresh
  useEffect(() => {
    setCurrentPage(1)
  }, [activeFilter, appointments])

  // --- Load Appointments ---
  async function loadAppointments() {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('technician_id', user.id)
        .order('created_at', { ascending: false })

      if (error) return console.error(error)

      setAppointments((data || []).map(a => ({ ...a, photos: a.photos || [] })))
    } catch (err) {
      console.error(err)
    }
  }

  // --- Load Preventive Maintenance Reminders ---
  async function loadMaintenanceReminders() {
    try {
      const { data: maintenanceData, error: maintenanceError } = await supabase
        .from('maintenance')
        .select('*')
        .eq('status', 'pending')
        .order('date', { ascending: true })

      if (maintenanceError) return console.error(maintenanceError)

      const { data: bookingsData, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, service, service_id')

      if (bookingsError) return console.error(bookingsError)

      const mapped = (maintenanceData || []).map(m => {
        const booking = (bookingsData || []).find(b => b.service_id === m.service_id)
        return { ...m, service_name: booking?.service || 'Service' }
      })

      setMaintenanceReminders(mapped)
    } catch (err) {
      console.error(err)
    }
  }

  // --- Setup Realtime ---
  function setupRealtime() {
    subscriptionRef.current?.unsubscribe()
    subscriptionRef.current = supabase
      .channel('public:bookings')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings' },
        payload => {
          if (payload.new?.technician_id === user.id || payload.old?.technician_id === user.id) {
            loadAppointments()
          }
          loadMaintenanceReminders()
        }
      )
      .subscribe()
  }

  // --- Filter Appointments ---
  function getFilteredAppointments() {
    if (activeFilter === 'all') return appointments
    return appointments.filter(a => a.status === activeFilter)
  }

  function getStatusColor(status) {
    const STATUS_COLORS = {
      assigned: '#f59e0b',
      in_progress: '#3b82f6',
      completed: '#10b981'
    }
    return STATUS_COLORS[status] || '#6b7280'
  }

  function handleAppointmentClick(apt) {
    const serviceId = apt.service_id || crypto.randomUUID()
    const updatedApt = {
      ...apt,
      service_id: serviceId,
      photos: apt.photos || [],
      work_notes: apt.work_notes || ''
    }
    setSelectedAppointment(updatedApt)
    setWorkPhotos(updatedApt.photos)
    setNotes(updatedApt.work_notes)
    setScreen('details')
  }

async function startWork(apt) {
  if (apt.status !== 'in_progress') {
    const { error } = await supabase
      .from('bookings')
      .update({ status: 'in_progress', service_status: 'in_progress' })
      .eq('id', apt.id);

    if (error) {
      console.error('Error updating status to in_progress:', error.message);
      alert('Failed to start work: ' + error.message);
      return;
    }

    // Update local state for appointment
    setSelectedAppointment({ ...apt, status: 'in_progress' });
    setWorkPhotos(apt.photos || []);
    setNotes(apt.work_notes || '');

    // Alert for "Start Work"
    alert('✅ Work started! Please take a photo to document the work start.');

    // Show camera for "Start Work" photo
    setCameraMode('before');
    setShowCamera(true);
  } else {
    alert('The work is already in progress.');
  }
}

  function handleFinishedWork(apt) {
    const updatedApt = {
      ...apt,
      photos: apt.photos || [],
      work_notes: apt.work_notes || ''
    }
    setSelectedAppointment(updatedApt)
    setWorkPhotos(updatedApt.photos || [])
    setNotes(updatedApt.work_notes || '')
    setScreen('details')
  }

async function handlePhotoCapture(photoUrl) {
  if (!selectedAppointment) return;

  const photo = {
    id: Date.now() + Math.random(),
    type: cameraMode,  // This will be 'before' for start-of-work photo, 'after' for end-of-work
    url: photoUrl,
    timestamp: new Date().toISOString()
  };

  const updatedPhotos = [...workPhotos.filter(p => p.type !== cameraMode), photo];

  try {
    // Save the photo to the 'bookings' table in Supabase
    const { error } = await supabase
      .from('bookings')
      .update({ photos: updatedPhotos })
      .eq('id', selectedAppointment.id);  // Ensure we update the correct booking

    if (error) throw error;

    // Update the local state for work photos
    setWorkPhotos(updatedPhotos);

    // Conditional Alert based on cameraMode (start or end work)
    if (cameraMode === 'before') {
      alert('✅ Start Work photo submitted successfully!');  // Success alert for start-of-work
    } else if (cameraMode === 'after') {
      alert('✅ End of Work photo submitted successfully!');  // Success alert for end-of-work
    }

  } catch (err) {
    console.error('Failed to save photo:', err);
    alert('❌ Failed to save photo');
  }

  // Hide the camera after submission
  setShowCamera(false);
}
async function completeJob() {  
  if (!selectedAppointment) return;  
  
  // Check if both before and after photos are captured  
  if (!workPhotos.find(p => p.type === 'before') || !workPhotos.find(p => p.type === 'after')) {  
    return alert('📸 You must capture BOTH start and end photos before completing the job.');  
  }  
  
  try {  
    const serviceId = selectedAppointment.service_id || crypto.randomUUID();  
    const userId = selectedAppointment.user_id;  
  
    if (!userId) return alert('❌ Missing user_id for maintenance record.');  
  
    // Update the booking status to completed  
    const { error: bookingError } = await supabase  
      .from('bookings')  
      .update({  
        status: 'completed',  
        service_status: 'completed',  
        work_notes: notes,  
        photos: workPhotos,  
        service_id: serviceId  
      })  
      .eq('id', selectedAppointment.id);  
  
    if (bookingError) throw bookingError;  
  
    // Get the interval days from preventiveIntervals object based on service_id
    const intervalDays = preventiveIntervals[selectedAppointment.service_id] || 30; // Default to 30 if not found
  
    // Calculate the maintenance date based on the correct interval (using preventiveIntervals)
    const maintenanceDate = new Date();
    maintenanceDate.setDate(maintenanceDate.getDate() + intervalDays); // Add the interval to today's date
  
    // Calculate the days left
    const diffTime = maintenanceDate - new Date();
    const daysLeft = Math.max(Math.ceil(diffTime / (1000 * 60 * 60 * 24)), 0);
  
    // Define the next action message
    const nextAction = `Scheduled maintenance in ${intervalDays} day(s)`;
  
    // Create the maintenance payload
    const maintenancePayload = {
      user_id: userId,
      service_id: serviceId,
      status: 'pending',
      notes: notes || '',
      date: maintenanceDate.toISOString(),
      reminder_days: intervalDays, // Use the intervalDays for reminder
    };
  
    // Insert the preventive maintenance record
    const { error: maintenanceError } = await supabase
      .from('maintenance')
      .insert([maintenancePayload]);

    if (maintenanceError) throw maintenanceError;

    // Set the UI back to appointments screen
    setSelectedAppointment(null);
    setWorkPhotos([]);
    setNotes('');
    setScreen('appointments');
    loadAppointments();
    loadMaintenanceReminders();

    // Show success alert
    alert('✅ Job completed & preventive maintenance scheduled!');

  } catch (err) {
    console.error('Error completing job:', err);
    alert('❌ Failed: ' + (err.message || JSON.stringify(err)));
  }
}
  // --- Pagination Logic ---
  const filteredAppointments = getFilteredAppointments()
  const totalPages = Math.ceil(filteredAppointments.length / itemsPerPage)
  const startIndex = (currentPage - 1) * itemsPerPage
  const endIndex = startIndex + itemsPerPage
  const paginatedAppointments = filteredAppointments.slice(startIndex, endIndex)

  function goToPage(page) {
    if (page < 1 || page > totalPages) return
    setCurrentPage(page)
  }

  // --- Show Camera Screen ---
  if (showCamera) {
    return (
      <div className="tech-app">
        <Camera
          onCapture={handlePhotoCapture}
          title={`📸 ${cameraMode.toUpperCase()} PHOTO`}
          onClose={() => setShowCamera(false)}
        />
      </div>
    )
  }

  // --- Main Dashboard ---
  return (
    <div className="tech-app">
      <header className="tech-header">
        <h1>🔧 Technician Dashboard</h1>
        <div className="tech-info">
          <img
            src={user?.avatar_url || '/default-avatar.png'}
            className="tech-avatar"
            alt="avatar"
          />
          <span className="tech-name">
            <a href="#" onClick={showTechnicianProfile}>
                👤 {technician?.name || 'Technician'} 
            </a>
          </span>
          <button onClick={onLogout} className="btn-logout-tech">🚪 Logout</button>
        </div>
      </header>

{showProfile && technician && (
  <div className="modal">
    <div className="modal-content">
      <span className="close-btn" onClick={() => setShowProfile(false)}>&times;</span>
      <h2>Technician Profile</h2>
      <p>Name: {technician?.name || 'N/A'}</p>
      <p>Email: {technician?.email || 'N/A'}</p>
      <p>Role: {technician?.role || 'technician'}</p>  {/* Default to 'technician' */}
    </div>
  </div>
)}

      <StatsGrid appointments={appointments} />

      {screen === 'appointments' && (
        <main className="tech-main">
          <div className="screen-header">
            <h2>📋 Assigned Jobs</h2>
            <p>
              {filteredAppointments.length} jobs
              {totalPages > 0 ? ` • Page ${currentPage} of ${totalPages}` : ''}
            </p>
          </div>

          <div className="status-filter">
            {['all', 'assigned', 'in_progress', 'completed'].map(s => (
              <button
                key={s}
                className={`filter-btn ${activeFilter === s ? 'active' : ''}`}
                onClick={() => setActiveFilter(s)}
              >
                {s.replace('_', ' ')}
              </button>
            ))}
          </div>

          <div className="appointments-list">
            {paginatedAppointments.length > 0 ? (
              paginatedAppointments.map(apt => (
                <div
                  key={apt.id}
                  className="appointment-card"
                  onClick={() => handleAppointmentClick(apt)}
                >
                  <div className="apt-header">
                    <h3>{apt.service}</h3>
                    <span
                      className="status-badge"
                      style={{ backgroundColor: getStatusColor(apt.status) }}
                    >
                      {apt.status}
                    </span>
                  </div>

                  <div className="apt-details">
                    <div className="detail-row">👤 {apt.full_name}</div>
                    <div className="detail-row">📅 {apt.date} @ {apt.time}</div>
                    <div className="detail-row">📍 {apt.address}</div>
                    <div className="detail-row">📞 {apt.mobile_number}</div>
                    <div className="detail-row">❄️ {apt.room_area} m²</div>
                  </div>

                  {apt.status !== 'completed' && (
                    <div className="work-buttons">
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          startWork(apt)
                        }}
                        className="btn-start-work"
                      >
                        🚀 Start Work
                      </button>

                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          setSelectedAppointment({
                            ...apt,
                            photos: apt.photos || [],
                            work_notes: apt.work_notes || ''
                          })
                          setWorkPhotos(apt.photos || [])
                          setNotes(apt.work_notes || '')
                          setCameraMode('after')
                          setScreen('photos')
                        }}
                        className="btn-finished-work"
                      >
                        ✅ Finished Work
                      </button>
                    </div>
                  )}
                </div>
              ))
            ) : (
              <div className="no-appointments">
                <p>No jobs found.</p>
              </div>
            )}
          </div>

          {totalPages > 1 && (
            <div className="pagination">
              <button
                className="pagination-btn"
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
              >
                ← Prev
              </button>

              {Array.from({ length: totalPages }, (_, index) => index + 1).map(page => (
                <button
                  key={page}
                  className={`pagination-btn ${currentPage === page ? 'active-page' : ''}`}
                  onClick={() => goToPage(page)}
                >
                  {page}
                </button>
              ))}

              <button
                className="pagination-btn"
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
              >
                Next →
              </button>
            </div>
          )}
        </main>
      )}

      {screen === 'details' && selectedAppointment && (
        <main className="tech-main">
          <button onClick={() => setScreen('appointments')} className="btn-back">← Back</button>
          <div className="apt-full-details">
            <h2>{selectedAppointment.service}</h2>
            <p>{selectedAppointment.address}</p>
            <div className="detail-card">
              <p><b>Customer:</b> {selectedAppointment.full_name}</p>
              <p>
                <b>Phone:</b> {selectedAppointment.mobile_number}{' '}
                <a href={`tel:${selectedAppointment.mobile_number}`} className="btn-call">📱 Call</a>
              </p>
              <p><b>Date:</b> {selectedAppointment.date}</p>
              <p><b>Time:</b> {selectedAppointment.time}</p>
              <p><b>Unit Area:</b> {selectedAppointment.room_area} m²</p>
              <p><b>Notes:</b> {selectedAppointment.notes}</p>
            </div>

            {selectedAppointment.status !== 'completed' && (
              <button
                onClick={() => setScreen('photos')}
                className="btn-start-work-full"
              >
                📸 Work Photos & Notes
              </button>
            )}
          </div>
        </main>
      )}

      {screen === 'photos' && selectedAppointment && (
        <main className="tech-main">
          <button onClick={() => setScreen('details')} className="btn-back">← Back</button>

          <div className="work-log">
            <h2>📸 Work Documentation</h2>

            <div className="photos-grid">
              {workPhotos.map(p => (
                <div key={p.id} className="photo-item">
                  <img
                    src={p.url}
                    alt=""
                    style={{ width: '100%', objectFit: 'contain', maxHeight: '300px' }}
                  />
                  <div className="photo-label">{p.type.toUpperCase()}</div>
                </div>
              ))}
            </div>

            <div className="actions">
              {!workPhotos.find(p => p.type === 'before') && (
                <button
                  onClick={() => {
                    setCameraMode('before')
                    setShowCamera(true)
                  }}
                  className="btn-add-photo"
                >
                  📸 Start Work Photo
                </button>
              )}

              {workPhotos.find(p => p.type === 'before') && !workPhotos.find(p => p.type === 'after') && (
                <button
                  onClick={() => {
                    setCameraMode('after')
                    setShowCamera(true)
                  }}
                  className="btn-end-work"
                >
                  🛑 End Work Photo
                </button>
              )}

              {workPhotos.find(p => p.type === 'before') && workPhotos.find(p => p.type === 'after') && (
                <button onClick={completeJob} className="btn-complete-job">
                  ✓ Complete Job
                </button>
              )}
            </div>

            <div className="notes-section">
              <h3>📝 Notes</h3>
              <textarea
                value={notes}
                onChange={e => setNotes(e.target.value)}
                className="notes-input"
              />
            </div>
          </div>
        </main>
      )}
    </div>
  )
}